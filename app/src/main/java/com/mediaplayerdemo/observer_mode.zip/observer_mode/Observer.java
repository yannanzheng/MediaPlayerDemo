package com.mediaplayerdemo.observer_mode;

/**
 * Created by jephy on 7/18/17.
 */

public interface Observer {
    void update(String string);
}
